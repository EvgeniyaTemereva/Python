a = "The"
b = "Developer’s"
c = "Dilemma"
print(f"{a} {b} {c}")
numb1 = int(input("Enter any number: "))
numb2 = int(input("Enter any number one more time: "))
print(f"You have chosen the numbers {numb1} and {numb2}")
word = input(" What can I do for you this morning?: ")
print(f"{word} - Hey, watch out!")


